#Twitter

Twitter created by PHP / Laravel


#Installation

move .env.example to .env

edit your env file

php artisan key:generate

php artisan migrate

php artisan storage:link

start using it!
