window.$ = window.jQuery = require('jquery');
