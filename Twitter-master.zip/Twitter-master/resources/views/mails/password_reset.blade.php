<div bgcolor="#F5F8FA" style="margin:0;padding:0">
   <table cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="#F5F8FA" style="background-color:#f5f8fa;padding:0;margin:0;line-height:1px;font-size:1px" class="m_5059781178865084156body_wrapper">
      <tbody>
         <tr>
            <td align="center" style="padding:0;margin:0;line-height:1px;font-size:1px">
               <table class="m_5059781178865084156collapse" id="m_5059781178865084156header" align="center" width="448" style="width:448px;padding:0;margin:0;line-height:1px;font-size:1px" bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0">
                  <tbody>
                     <tr>
                        <td style="min-width:448px;padding:0;margin:0;line-height:1px;font-size:1px" class="m_5059781178865084156cut"> <img src="https://ci3.googleusercontent.com/proxy/u8bJD0DXSMkQW8P7jTvC8HpN6qbqHn_LLx_JNX8OR7so0YS-7SMRfNdT9IGdLgJ2maYaJWALapsOYyeNt5CfzXHvcNyVzvwwitpA0l-ZUVkYknAcvSCjCk-A=s0-d-e1-ft#https://ea.twimg.com/email/self_serve/media/spacer-1402696023930.png" style="min-width:448px;height:1px;margin:0;padding:0;display:block;border:none;outline:none" class="CToWUd"> </td>
                     </tr>
                  </tbody>
               </table>
            </td>
         </tr>
         <tr>
            <td align="center" style="padding:0;margin:0;line-height:1px;font-size:1px">
               <table class="m_5059781178865084156collapse" id="m_5059781178865084156header" align="center" width="448" style="width:448px;background-color:#ffffff;padding:0;margin:0;line-height:1px;font-size:1px" bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0">
                  <tbody>
                     <tr>
                        <td colspan="4" height="24" style="height:24px;padding:0;margin:0;line-height:1px;font-size:1px" class="m_5059781178865084156logo_space"> &nbsp; </td>
                     </tr>
                     <tr align="right">
                        <td width="24" class="m_5059781178865084156margin" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                        <td align="right" style="padding:0;margin:0;line-height:1px;font-size:1px"> <a href="#m_5059781178865084156_" style="text-decoration:none;border-style:none;border:0;padding:0;margin:0"> <img width="32" align="right" src="https://ci5.googleusercontent.com/proxy/wO98xRkjt309ATulbtC047dWqNSu52weE4uwgtPMto1gX8_gIboYkcrVx0d4wxg8vHnrr7lbpJxp5UG45Od8HMgeHDfFmFag9cLsCPe9Yqbv6oNFzsTI6u4qGPKYY42TsVq_0Q=s0-d-e1-ft#https://ea.twimg.com/email/self_serve/media/Twitter_logo_180-1468901451975.png" style="width:32px;margin:0;padding:0;display:block;border:none;outline:none" class="CToWUd"> </a> </td>
                        <td width="24" class="m_5059781178865084156margin" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>
                     <tr>
                        <td colspan="3" height="24" style="height:24px;padding:0;margin:0;line-height:1px;font-size:1px" class="m_5059781178865084156logo_space"> <img width="1" height="1" style="display:block;margin:0;padding:0;display:block;border:none;outline:none" src="https://ci3.googleusercontent.com/proxy/K80l0PBx8bOswqR5FxNInZvnGoLINdvcl44BQr0ADgvtw7IX90E9hPLxPotdA8h7WXiKEdlwKpmJZkhjfN3MJLHJZ5iWpeLXZOtd1SppcvDgFj25HZXchYSVP0Wu3bXGa7h_eTts_3vqm2hSgrBsLmGCBXBjarXIFX2baLaFyTBwAPPzqrmlJKI5II8xtteR7ZYE4AXmRdR6Ri51Iucd=s0-d-e1-ft#https://twitter.com/scribe/ibis?t=1&amp;cn=cGFzc3dvcmRfcmVzZXRfdjI%3D&amp;iid=dc14ca6b047c4c6b869d17c37c752eec&amp;uid=783338385452720128&amp;nid=248+20" class="CToWUd"> </td>
                     </tr>
                  </tbody>
               </table>
               <table class="m_5059781178865084156collapse" id="m_5059781178865084156header" align="center" width="448" style="width:448px;background-color:#ffffff;padding:0;margin:0;line-height:1px;font-size:1px" bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0">
                  <tbody>
                     <tr align="left;">
                        <td width="24" class="m_5059781178865084156margin" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                        <td align="left;" style="padding:0;margin:0;line-height:1px;font-size:1px">
                           <table class="m_5059781178865084156collapse" cellpadding="0" cellspacing="0" border="0" style="padding:0;margin:0;line-height:1px;font-size:1px">
                              <tbody>
                                 <tr>
                                    <td align="left;" class="m_5059781178865084156h2" style="padding:0;margin:0;line-height:1px;font-size:1px;font-family:'HelveticaNeue','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:24px;line-height:32px;font-weight:bold;color:#292f33;text-align:left;text-decoration:none"> Reset your password? </td>
                                 </tr>
                                 <tr>
                                    <td height="12" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                                 </tr>
                                 <tr>
                                    <td align="left;" class="m_5059781178865084156body-text" style="padding:0;margin:0;line-height:1px;font-size:1px;font-family:'HelveticaNeue','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:400;color:#292f33;text-align:left;text-decoration:none"> If you requested a password reset for @sniffabyte, click the button below. If you didn't make this request, ignore this email. </td>
                                 </tr>
                                 <tr>
                                    <td height="24" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                                 </tr>
                                 <tr>
                                    <td align="left;" style="padding:0;margin:0;line-height:1px;font-size:1px">
                                       <table border="0" cellspacing="0" cellpadding="0" style="padding:0;margin:0;line-height:1px;font-size:1px">
                                          <tbody>
                                             <tr>
                                                <td style="padding:0;margin:0;line-height:1px;font-size:1px">
                                                   <table width="100%" border="0" cellspacing="0" cellpadding="0" style="padding:0;margin:0;line-height:1px;font-size:1px">
                                                      <tbody>
                                                         <tr>
                                                            <td style="padding:0;margin:0;line-height:1px;font-size:1px">
                                                               <table border="0" cellspacing="0" cellpadding="0" style="padding:0;margin:0;line-height:1px;font-size:1px">
                                                                  <tbody>
                                                                     <tr>
                                                                        <td align="center" class="m_5059781178865084156bulletproof-btn-1" bgcolor="#1DA1F2" style="padding:0;margin:0;line-height:1px;font-size:1px;border-radius:4px;line-height:12px"><a href="{{$url}}" class="m_5059781178865084156bulletproof-btn-2" style="text-decoration:none;border-style:none;border:0;padding:0;margin:0;font-size:12px;font-family:'HelveticaNeue','Helvetica Neue',Helvetica,Arial,sans-serif;color:#ffffff;text-decoration:none;border-radius:4px;padding:8px 17px;border:1px solid #1da1f2;display:inline-block;font-weight:bold" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://twitter.com/i/redirect?url%3Dhttps%253A%252F%252Ftwitter.com%252Faccount%252Fconfirm_email_reset%253Freset_type%253De%2526user_id%253D783338385452720128%2526token%253DPvAJZKrHFd%252521ua2NWAGeJLu8Eo_UAeyrttFaNZac9plg%25253D-1535826173591%2526confirm_pending_email%253D0%2526token_version%253D0%2526password_reset_cause%253Duser%2526cn%253DcGFzc3dvcmRfcmVzZXRfdjI%25253D%26t%3D1%2B1535826173615%26cn%3DcGFzc3dvcmRfcmVzZXRfdjI%253D%26sig%3Dd28bd0eee634512200fd1eea23e79d690644c075%26iid%3Ddc14ca6b047c4c6b869d17c37c752eec%26uid%3D783338385452720128%26nid%3D248%2B1393&amp;source=gmail&amp;ust=1535913949488000&amp;usg=AFQjCNFW_rhenZtZgFu7tD9vgjPHEgkk9g">
                                                                           <strong>Reset password</strong>
                                                                           </a>
                                                                        </td>
                                                                     </tr>
                                                                  </tbody>
                                                               </table>
                                                            </td>
                                                         </tr>
                                                      </tbody>
                                                   </table>
                                                </td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td height="36" style="height:36px;padding:0;margin:0;line-height:1px;font-size:1px"></td>
                                 </tr>
                              </tbody>
                           </table>
                        </td>
                        <td width="24" class="m_5059781178865084156margin" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>
                     <tr>
                        <td height="1" style="line-height:1px;display:block;height:1px;background-color:#f5f8fa;padding:0;margin:0;line-height:1px;font-size:1px"></td>
                        <td align="center" style="padding:0;margin:0;line-height:1px;font-size:1px">
                           <table width="100%" align="center" cellpadding="0" cellspacing="0" border="0" class="m_5059781178865084156edu-module" style="padding:0;margin:0;line-height:1px;font-size:1px;background-color:#ffffff;border-radius:5px">
                              <tbody>
                                 <tr>
                                    <td height="1" style="line-height:1px;display:block;height:1px;background-color:#f5f8fa;padding:0;margin:0;line-height:1px;font-size:1px"></td>
                                 </tr>
                              </tbody>
                           </table>
                        </td>
                        <td height="1" style="line-height:1px;display:block;height:1px;background-color:#f5f8fa;padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>
                     <tr>
                        <td colspan="3" height="24" class="m_5059781178865084156edu-space" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>
                     <tr>
                        <td width="24" class="m_5059781178865084156edu-margins" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                        <td align="center" style="padding:0;margin:0;line-height:1px;font-size:1px">
                           <table width="100%" align="center" cellpadding="0" cellspacing="0" border="0" class="m_5059781178865084156edu-module" bgcolor="#F5F8FA" style="padding:0;margin:0;line-height:1px;font-size:1px;background-color:#ffffff;border-radius:5px">
                              <tbody>
                                  <tr>
                                     <td align="left" style="padding:0;margin:0;line-height:1px;font-size:1px">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="padding:0;margin:0;line-height:1px;font-size:1px">
                                           <tbody>
                                              <tr>
                                                 <td class="m_5059781178865084156edu-header" style="padding:0;margin:0;line-height:1px;font-size:1px;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;line-height:22px;text-align:left;color:#8899a6"> <strong>How do I know an email is from Twitter?</strong> </td>
                                              </tr>
                                              <tr>
                                                 <td colspan="3" height="12" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                                              </tr>
                                              <tr>
                                                 <td class="m_5059781178865084156edu-text" style="padding:0;margin:0;line-height:1px;font-size:1px;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:19px;font-weight:400;text-align:left;color:#8899a6"> Links in this email will start with “<span class="m_5059781178865084156no-link"><a href="#m_5059781178865084156_" style="text-decoration:none;border-style:none;border:0;padding:0;margin:0;color:#8899a6;text-decoration:none">https://</a></span>” and contain “<span class="m_5059781178865084156no-link"><a href="https://twitter.com/i/redirect?url=https%3A%2F%2Ftwitter.com%2F%3Frefsrc%3Demail&amp;t=1+1535826173616&amp;cn=cGFzc3dvcmRfcmVzZXRfdjI%3D&amp;sig=8b3358c203db0d6b00dc438fff72292220e31d5c&amp;iid=dc14ca6b047c4c6b869d17c37c752eec&amp;uid=783338385452720128&amp;nid=248+1554" style="text-decoration:none;border-style:none;border:0;padding:0;margin:0;color:#8899a6;text-decoration:none" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://twitter.com/i/redirect?url%3Dhttps%253A%252F%252Ftwitter.com%252F%253Frefsrc%253Demail%26t%3D1%2B1535826173616%26cn%3DcGFzc3dvcmRfcmVzZXRfdjI%253D%26sig%3D8b3358c203db0d6b00dc438fff72292220e31d5c%26iid%3Ddc14ca6b047c4c6b869d17c37c752eec%26uid%3D783338385452720128%26nid%3D248%2B1554&amp;source=gmail&amp;ust=1535913949488000&amp;usg=AFQjCNHCAB0XjOhU0FRSVEx_uJhpzrM_pg">twitter.com</a></span>.” Your browser will also display a padlock icon to let you know a site is secure. </td>
                                              </tr>
                                           </tbody>
                                        </table>
                                     </td>
                                  </tr>
                              </tbody>
                           </table>
                        </td>
                        <td width="24" class="m_5059781178865084156edu-margins" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>

                     <tr>
                        <td colspan="3" height="24" class="m_5059781178865084156edu-space" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>
                     <tr>
                        <td width="24" class="m_5059781178865084156edu-margins" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                        <td align="center" style="padding:0;margin:0;line-height:1px;font-size:1px">
                           <table width="100%" align="center" cellpadding="0" cellspacing="0" border="0" class="m_5059781178865084156edu-module" bgcolor="#F5F8FA" style="padding:0;margin:0;line-height:1px;font-size:1px;background-color:#ffffff;border-radius:5px">
                              <tbody>
                                  <tr>
                                     <td align="left" style="padding:0;margin:0;line-height:1px;font-size:1px">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="padding:0;margin:0;line-height:1px;font-size:1px">
                                           <tbody>
                                              <tr>
                                                  <hr>
                                              </tr>
                                              <tr>
                                                 <td colspan="3" height="12" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                                              </tr>
                                              <tr>
                                                 <td class="m_5059781178865084156edu-text" style="padding:0;margin:0;line-height:1px;font-size:1px;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:19px;font-weight:400;text-align:left;color:#8899a6"> Links in this email will start with “<span class="m_5059781178865084156no-link"><a href="#m_5059781178865084156_" style="text-decoration:none;border-style:none;border:0;padding:0;margin:0;color:#8899a6;text-decoration:none">If you’re having trouble clicking the "Reset Password" button, copy and paste the URL below into your web browser: <a href="{{$url}}">{{$url}}</a></td>
                                              </tr>
                                           </tbody>
                                        </table>
                                     </td>
                                  </tr>
                              </tbody>
                           </table>
                        </td>
                        <td width="24" class="m_5059781178865084156edu-margins" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>
                     <tr>
                        <td colspan="3" height="24" class="m_5059781178865084156edu-space" style="padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>
                     <tr>
                        <td height="1" style="line-height:1px;display:block;height:1px;background-color:#f5f8fa;padding:0;margin:0;line-height:1px;font-size:1px"></td>
                        <td align="center" style="padding:0;margin:0;line-height:1px;font-size:1px">
                           <table width="100%" align="center" cellpadding="0" cellspacing="0" border="0" class="m_5059781178865084156edu-module" style="padding:0;margin:0;line-height:1px;font-size:1px;background-color:#ffffff;border-radius:5px">
                              <tbody>
                                 <tr>
                                    <td height="1" style="line-height:1px;display:block;height:1px;background-color:#f5f8fa;padding:0;margin:0;line-height:1px;font-size:1px"></td>
                                 </tr>
                              </tbody>
                           </table>
                        </td>
                        <td height="1" style="line-height:1px;display:block;height:1px;background-color:#f5f8fa;padding:0;margin:0;line-height:1px;font-size:1px"></td>
                     </tr>
                  </tbody>
               </table>
            </td>
         </tr>
      </tbody>
   </table>
   <div class="yj6qo"></div>
   <div class="adL"></div>
</div>
