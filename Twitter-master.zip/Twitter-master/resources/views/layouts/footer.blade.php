    @yield('scripts')
    </body>
</html>
